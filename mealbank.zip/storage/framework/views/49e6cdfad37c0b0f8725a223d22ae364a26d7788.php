<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>calo-edit</title>
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
   </head>
    <body>
       <h1 class="title">編集</h1>
       <div class="content">
           
           <form action="/meals/<?php echo e($meal->id); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PUT'); ?>
               <div class='content__title'>
                   <h2>meal</h2>
                   <input type="text" name='meal[name]' value="<?php echo e($meal->name); ?>">
               </div>
               <div class='content__body'>
                   <h2>kcal</h2>
                   <input type='text' name='meal[calorie]' value="<?php echo e($meal->calorie); ?>">
               </div>
               <input type="submit" value="更新">
           </form>
    <div class="footer">
        <a href="/">戻る</a>
    </div>
       </div>
    </body>
</html><?php /**PATH /home/ec2-user/environment/bank/resources/views/meals/edit.blade.php ENDPATH**/ ?>