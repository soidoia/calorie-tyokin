<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>calo-Bank</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        
    </head>
    <body>
        <h1>カロリー貯金箱</h1>
        <a href='/posts/create'>入力画面</a>
        
        <div class='posts'>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='post'>
                    <h2 class='title'>
                        <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
                    </h2>
                    <p class='body'><?php echo e($post->body); ?></p>
                    <!-- 以下を追記 -->
                    <form action="/posts/<?php echo e($post->id); ?>" id=for,_<?php echo e($post->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" onclick="deletePost(<?php echo e($post->id); ?>)">delete</button>
                    </form>
                    <a href=""><?php echo e($post->meal->name); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </div>
    <script>
        function deletePost(id) {
            'use strict'
            
            if (confirm('削除すると復元できません。\n本当に削除しますか？')) {
                document.getElementByID('form_${id}').submit();
            }
        }
    </script>
    </body>
</html><?php /**PATH /home/ec2-user/environment/bank/resources/views/posts/index.blade.php ENDPATH**/ ?>