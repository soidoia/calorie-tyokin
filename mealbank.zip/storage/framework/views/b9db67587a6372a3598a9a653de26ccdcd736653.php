<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>Calo-Bank</title>
   </head>
    <body>
        <h1>カロリー貯金箱</h1>
       <form action="/posts" method="POST">
           <?php echo csrf_field(); ?>
           <div class="meal">
               <h2>食品名</h2>
               <select name="post[meal_id]">
                    <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($meal->id); ?>"><?php echo e($meal->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
               </select>
           </div>
           <input type="submit" value="保存"/> 
       </form>
       <div class="footer">
           <a href="/">戻る</a>
       </div>
    </body>
</html><?php /**PATH /home/ec2-user/environment/bank/resources/views/posts/create.blade.php ENDPATH**/ ?>